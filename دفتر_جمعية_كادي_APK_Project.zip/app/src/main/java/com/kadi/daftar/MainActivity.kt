package com.kadi.daftar

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val fee = 1000
    private val prefs by lazy {
        getSharedPreferences("kadi", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        refresh()

        findViewById<Button>(R.id.addMember).setOnClickListener { addMember() }
        findViewById<Button>(R.id.payments).setOnClickListener { payments() }
        findViewById<Button>(R.id.report).setOnClickListener { report() }
    }

    private fun members(): MutableSet<String> =
        (prefs.getStringSet("members", emptySet()) ?: emptySet()).toMutableSet()

    private fun refresh() {
        val m = members()
        var paid = 0

        m.forEach { name ->
            if (prefs.getBoolean("paid_$name", false)) {
                paid += fee
            }
        }

        val due = m.size * fee - paid

        findViewById<TextView>(R.id.summary).text =
            "الاشتراك الشهري: $fee دج\n" +
            "عدد الأعضاء: ${m.size}\n" +
            "المدفوع: $paid دج\n" +
            "المتأخر: $due دج"
    }

    private fun addMember() {
        val input = EditText(this).apply {
            hint = "اسم العضو"
            textDirection = android.view.View.TEXT_DIRECTION_ANY_RTL
        }

        AlertDialog.Builder(this)
            .setTitle("إضافة عضو")
            .setView(input)
            .setPositiveButton("حفظ") { _, _ ->
                val name = input.text.toString().trim()

                if (name.isNotEmpty()) {
                    val m = members()
                    m.add(name)
                    prefs.edit().putStringSet("members", m).apply()
                    refresh()
                } else {
                    Toast.makeText(
                        this,
                        "أدخل اسم العضو",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun payments() {
        val m = members().toList().sorted()

        if (m.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("دفتر الدفع")
                .setMessage("لا يوجد أعضاء. أضف أعضاء أولاً.")
                .setPositiveButton("إغلاق", null)
                .show()
            return
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }

        m.forEach { name ->
            val cb = CheckBox(this).apply {
                text = "$name — $fee دج"
                isChecked = prefs.getBoolean("paid_$name", false)
            }

            cb.setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("paid_$name", checked).apply()
                refresh()
            }

            box.addView(cb)
        }

        val scroll = ScrollView(this).apply {
            addView(box)
        }

        AlertDialog.Builder(this)
            .setTitle("دفتر الدفع — الشهر الحالي")
            .setView(scroll)
            .setPositiveButton("إغلاق", null)
            .show()
    }

    private fun report() {
        val m = members().toList().sorted()

        val text = if (m.isEmpty()) {
            "لا يوجد أعضاء."
        } else {
            m.joinToString("\n") { name ->
                "$name : " +
                    if (prefs.getBoolean("paid_$name", false)) {
                        "دفع $fee دج"
                    } else {
                        "لم يدفع"
                    }
            }
        }

        AlertDialog.Builder(this)
            .setTitle("كشف الحساب")
            .setMessage(text)
            .setPositiveButton("إغلاق", null)
            .show()
    }
}
